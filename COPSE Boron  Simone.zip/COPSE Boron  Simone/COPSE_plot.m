%global pars
Clemensd18O=[-1.95;-2.11;-2;-2.13;-2.24;-2.21;-1.94;-2.01;-1.93;-1.88;-2.55;-3.03;-3.36;-3.26;-3.08;-2.97;-2.58;-3.3;-3;-3.05;-2.34;-2.6;-1.91;-2.11;-1.75;-2.04;-2.75;-2.67;-2.57;-2.15;-2.5;-2.65;-2.07;-2.71;-2.47;-2.28;-2.54;-2.47];
Clemensd13c=[0.46;0.47;0.32;1.59;1.98;2.6;2.97;3.09;3.13;2.94;2.26;1.13;-0.36;2.16;2.56;2.69;4.38;4.6;4.24;4.39;5.13;4.49;3.99;3.95;3.93;4.61;4.53;4.17;3.47;3.17;3.23;3.27;2.46;2.3;1.94;2.72;2.89;3.14];
Clemensages=-[183.69;183.64;183.56;183.43;183.37;183.32;183.26;183.19;183.15;183.11;183.08;183.04;182.93;182.82;182.74;182.66;182.53;182.45;182.38;182.34;182.23;182.18;182.14;182.04;181.96;181.87;181.77;181.69;181.57;181.46;181.37;181.09;180.75;180.55;180.42;180.24;180.08;179.87];

Tinad11B_micritic_S=[13.14;12.26;13.06;13.69;13.02;13.99;11.93;10.71;9.68;9.14;11.13;10.45;8.95;8.91;9.54;10.55;12.92;13.13;11.62];
Tinaage_micritic_S=-[188.020000000000;187.890000000000;187.210000000000;186.970000000000;186.840000000000;186.710000000000;183.720000000000;182.780000000000;182.560000000000;182.490000000000;182.450000000000;182.340000000000;182.230000000000;182.140000000000;181.960000000000;181.870000000000;180.080000000000;178.960000000000;178.780000000000];
Tinad11B_brachio_S=[13.54;13.25;13.87;13.87;13.81;13.91;13.78;13.94;13.78;13.78;13.58;13.59;13.63;14.82;13.93;13.03;13.00;13.13;13.57;13.96;13.55;13.22];
Tinaage_brachio_S=-[183.43;183.15;183.11;183.08;182.82;182.82;182.82;182.74;182.74;182.74;182.74;182.66;182.45;182.18;182.14;181.96;181.96;181.96;181.87;181.77;181.69;181.57];

Tinad11B_micritic_P=[15.42;15.83;16.25;15.70;15.72;13.27;13.29;12.88;11.12;9.92;11.48;12.25;10.96;12.98;12.16;15.37;14.44;15.34;14.24;16.13];
Tinaage_micritic_P=-[187.34;186.16;185.92;183.72;183.71;183.06;183.02;182.93;182.80;182.55;182.53;182.48;182.41;182.38;182.35;182.21;181.71;181.18;180.60;180.02];
Tinad11B_brachio_P=[14.79;14.69;13.84;13.75;13.27];
Tinaage_brachio_P=-[183.56;183.35;182.45;182.41;182.41];

KB1110_klochko1=1.0272; %fractionation specific term not actual KB
KB1110_klochko2=1.0194;


for i=1:length(Tinad11B_micritic_S)
    timemyr_data=Tinaage_micritic_S;
    timemyr_model=state.time_myr;
    ind = interp1(timemyr_model,1:length(timemyr_model),timemyr_data,'nearest');
    indfinal=min(ind);
    d11B_SM(i)=state.d11B(indfinal);
    disp(d11B_SM(i));
    pKB_SM(i)=state.pKB(indfinal);
    disp(pKB_SM(i))
    KB_SM(i)=10^(-pKB_SM(i));
    Klochko_num_MS(i)=(d11B_SM(i)-Tinad11B_micritic_S(i));
    Klochko_denom_MS(i)=d11B_SM(i)-KB1110_klochko1*Tinad11B_micritic_S(i)-1000*(KB1110_klochko1-1);
    Klochko_M_S_fixed(i)=pKB_SM(i)-log10(-1*(Klochko_num_MS(i)/Klochko_denom_MS(i)));
    Klochko_M_S_fixed(i)=real(Klochko_M_S_fixed(i));

end;

for i=1:length(Tinad11B_micritic_P)
    timemyr_data=Tinaage_micritic_P;
    timemyr_model=state.time_myr;
    ind = interp1(timemyr_model,1:length(timemyr_model),timemyr_data,'nearest');
    indfinal=min(ind);
    d11B_PM(i)=state.d11B(indfinal);
    pKB_PM(i)=state.pKB(indfinal);
    KB_PM(i)=10^(-pKB_PM(i));
    Klochko_num_MP(i)=(d11B_PM(i)-Tinad11B_micritic_P(i));
    Klochko_denom_MP(i)=d11B_PM(i)-KB1110_klochko1*Tinad11B_micritic_P(i)-1000*(KB1110_klochko1-1);
    Klochko_M_P_fixed(i)=pKB_PM(i)-log10(-1*(Klochko_num_MP(i)/Klochko_denom_MP(i)));
    Klochko_M_P_fixed(i)=real(Klochko_M_P_fixed(i));
end;

penman_a=2.4;
penman_eta=27.2;
alpha_lemarchand=1.019;


for i=1:length(Tinad11B_brachio_S)
    timemyr_data=Tinaage_brachio_S;
    timemyr_model=state.time_myr;
    ind = interp1(timemyr_model,1:length(timemyr_model),timemyr_data,'nearest');
    indfinal=min(ind);
    d11B_S(i)=state.d11B(indfinal);
    pKB_S(i)=state.pKB(indfinal);
    KB_S(i)=10^(-pKB_S(i));
    
    Lecuyer_fracS(i)=(Tinad11B_brachio_S(i)+1000)/(d11B_S(i)+1000);
    Lecuyer_B_S_fixed(i) = 8.9 - log10((0.023/(Lecuyer_fracS(i)-0.976))-1);
    Lecuyer_B_S_fixed(i)=real(Lecuyer_B_S_fixed(i));

    Penman_numS(i)=d11B_S(i)-Tinad11B_brachio_S(i)-penman_a;
    Penman_denomS(i)=d11B_S(i)-KB1110_klochko1*(Tinad11B_brachio_S(i)+penman_a)-penman_eta;
    Penman_B_S_fixed(i) = pKB_S(i)-log10((-1)*Penman_numS(i)/Penman_denomS(i));
    Penman_B_S_fixed(i)=real(Penman_B_S_fixed(i));
    
    Lemarchand_numS(i)=(Tinad11B_brachio_S(i)-d11B_S(i))*KB_S(i);
    Lemarchand_denomS(i)=d11B_S(i)-(Tinad11B_brachio_S(i)/alpha_lemarchand)-1000*(alpha_lemarchand-1);
    Lemarchand_B_S_fixed(i)=-log10(Lemarchand_numS(i)/Lemarchand_denomS(i));    
    Lemarchand_B_S_fixed(i)=real(Lemarchand_B_S_fixed(i));

    Jurikova_borate_B_S(i)=(Tinad11B_brachio_S(i)-11.52+39-d11B_S(i))/0.292;
    %Jurikova_borate_B_S(i)=Tinad11B_brachio_S(i);
    Jurikova_num_S(i)=d11B_S(i)-Jurikova_borate_B_S(i);
    Jurikova_denom_S(i)=d11B_S(i)-KB1110_klochko1*Jurikova_borate_B_S(i)-1000*(KB1110_klochko1-1);

    %Jurikova_num_S(i)=39-Jurikova_borate_B_S(i);
    %Jurikova_denom_S(i)=39-KB1110_klochko1*Jurikova_borate_B_S(i)-1000*(KB1110_klochko1-1);

    Jurikova_B_S_fixed(i)=pKB_S(i)-log10(-Jurikova_num_S(i)/Jurikova_denom_S(i));
    %Jurikova_B_S_fixed(i)=8.81-log10(-Jurikova_num_S(i)/Jurikova_denom_S(i));
    Jurikova_B_S_fixed(i)=real(Jurikova_B_S_fixed(i));
end;

for i=1:length(Tinad11B_brachio_P)
    timemyr_data=Tinaage_brachio_P;
    timemyr_model=state.time_myr;
    ind = interp1(timemyr_model,1:length(timemyr_model),timemyr_data,'nearest');
    indfinal=min(ind);
    d11B_P(i)=state.d11B(indfinal);
    pKB_P(i)=state.pKB(indfinal);
    KB_P(i)=10^(-pKB_P(i));
    
    Lecuyer_fracP(i)=(Tinad11B_brachio_P(i)+1000)/(d11B_P(i)+1000);
    Lecuyer_B_P_fixed(i) = 8.9 - log10((0.023/(Lecuyer_fracP(i)-0.976))-1);
    Lecuyer_B_P_fixed(i)=real(Lecuyer_B_P_fixed(i));
    
    Penman_numP(i)=d11B_P(i)-Tinad11B_brachio_P(i)-penman_a;
    Penman_denomP(i)=d11B_P(i)-KB1110_klochko1*(Tinad11B_brachio_P(i)+penman_a)-penman_eta;
    Penman_B_P_fixed(i) = pKB_P(i)-log10((-1)*Penman_numP(i)/Penman_denomP(i));
    Penman_B_P_fixed(i)=real(Penman_B_P_fixed(i));

    Lemarchand_numP(i)=(Tinad11B_brachio_P(i)-d11B_P(i))*KB_P(i);
    Lemarchand_denomP(i)=d11B_P(i)-(Tinad11B_brachio_P(i)/alpha_lemarchand)-1000*(alpha_lemarchand-1);
    Lemarchand_B_P_fixed(i)=-log10(Lemarchand_numP(i)/Lemarchand_denomP(i));
    Lemarchand_B_P_fixed(i)=real(Lemarchand_B_P_fixed(i));

    %Jurikova_borate_B_P(i)=(Tinad11B_brachio_P(i)-11.52)/0.292;
    Jurikova_borate_B_P(i)=(Tinad11B_brachio_P(i)-11.52+39-d11B_P(i))/0.292;

    %Jurikova_borate_B_P(i)=Tinad11B_brachio_P(i);
    Jurikova_num_P(i)=d11B_P(i)-Jurikova_borate_B_P(i);
    Jurikova_denom_P(i)=d11B_P(i)-KB1110_klochko1*Jurikova_borate_B_P(i)-1000*(KB1110_klochko1-1);

    %Jurikova_num_P(i)=39-Jurikova_borate_B_P(i);
    %Jurikova_denom_P(i)=39-KB1110_klochko1*Jurikova_borate_B_P(i)-1000*(KB1110_klochko1-1);


    
    
    Jurikova_B_P_fixed(i)=pKB_P(i)-log10(-Jurikova_num_P(i)/Jurikova_denom_P(i));
    %Jurikova_B_P_fixed(i)=8.81-log10(-Jurikova_num_P(i)/Jurikova_denom_P(i));
    Jurikova_B_P_fixed(i)=real(Jurikova_B_P_fixed(i));

    
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%   Plotting script   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% only plot if no tuning structure exists
if isempty(Gtune) == 1

    %%%% output to screen
    fprintf('running plotting script... \t')
    tic


%     %%%%%% make figure
%     figure('Color',[0.80 0.80 0.70])
%     
%     %%% load geochem data
%     load('data/data.mat')
% 
% 
%     %%%% GLOBAL FORCINGS
%     subplot(4,5,1)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     ylim([0 2.5])
%     xlabel('Time (Ma)')
%     ylabel('Relative forcing')
%     %%%% plot this model
%     plot(state.time_myr,state.DEGASS,'r','displayname','D')
%     plot(state.time_myr,state.BAS_AREA,'k','displayname','BA')
%      plot(state.time_myr,state.GRAN_AREA,'k--','displayname','GA')
%     plot(state.time_myr,state.EVO,'g','displayname','E')
%     plot(state.time_myr,state.W,'b','displayname','W')
%     plot(state.time_myr,state.Bforcing,'m','displayname','B')
%     %%%% Title
%     title('Forcings')
%     %%%% legend
%     l = legend ;
%     set(l,'fontsize',6)
%     set(l,'edgecolor','none')
%     set(l,'location','northwest')
% 
%     %%% Corg fluxes
%     subplot(4,5,2)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('Flux (mol/yr)')
%     %%%% plot this model
%     plot(state.time_myr,state.mocb,'b','displayname','mocb')
%     plot(state.time_myr,state.locb,'g','displayname','locb')
%     plot(state.time_myr,state.oxidw,'r','displayname','oxidw')
%     plot(state.time_myr,state.ocdeg,'k','displayname','ocdeg') 
%     %%%% Title
%     title('C_{org} fluxes')
%     %%%% legend
%     l = legend ;
%     set(l,'fontsize',6)
%     set(l,'edgecolor','none')
%     set(l,'location','northwest')
% 
%     %%% Ccarb fluxes
%     subplot(4,5,3)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('Flux (mol/yr)')
%     %%%% plot this model
%     plot(state.time_myr,state.silw,'r','displayname','silw')
%     plot(state.time_myr,state.carbw,'c','displayname','carbw')
%     plot(state.time_myr,state.sfw,'b','displayname','sfw')
%     plot(state.time_myr,state.mccb,'k','displayname','mccb') 
%     %%%% Title
%     title('C_{carb} fluxes')
%     %%%% legend
%     l = legend ;
%     set(l,'fontsize',6)
%     set(l,'edgecolor','none')
%     set(l,'location','northwest')
%    
%     %%% S fluxes
%     subplot(4,5,4)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     % ylim([0 5e12])
%     ylabel('Fluxes (mol/yr)')
%     %%%% plot this model
%     plot(state.time_myr,state.mpsb,'k','displayname','mpsb')
%     plot(state.time_myr,state.mgsb,'c','displayname','mgsb')
%     plot(state.time_myr,state.pyrw,'r','displayname','pyrw')
%     plot(state.time_myr,state.pyrdeg,'m','displayname','pyrdeg') 
%     plot(state.time_myr,state.gypw,'b','displayname','gypw')
%     plot(state.time_myr,state.gypdeg,'g','displayname','gypdeg') 
%     %%%% Title
%     title('S fluxes')
%     %%%% legend
%     l = legend ;
%     set(l,'fontsize',6)
%     set(l,'edgecolor','none')
%     set(l,'location','northwest')
%     
%     %%%% C SPECIES
%     subplot(4,5,5)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('Relative size')
%     %%%% plot this model
%     plot(state.time_myr,state.G/pars.G0,'k','displayname','G')
%     plot(state.time_myr,state.C/pars.C0,'c','displayname','C')
%     plot(state.time_myr,state.VEG,'g--','displayname','VEG')
%     %%%% Title
%     title('C reservoirs')
%     %%%% legend
%     l = legend ;
%     set(l,'fontsize',6)
%     set(l,'edgecolor','none')
%     set(l,'location','northwest')
%     
%     %%%% S SPECIES
%     subplot(4,5,6)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('Relative size')
%     %%%% plot this model
%     plot(state.time_myr,state.PYR/pars.PYR0,'k','displayname','PYR')
%     plot(state.time_myr,state.GYP/pars.GYP0,'c','displayname','GYP')
%     %%%% Title
%     title('S reservoirs')
%     %%%% legend
%     l = legend ;
%     set(l,'fontsize',6)
%     set(l,'edgecolor','none')
%     set(l,'location','northwest')
%     
%     %%% NUTRIENTS P N
%     subplot(4,5,7)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     ylim([0 3])
%     xlabel('Time (Ma)')
%     ylabel('Relative size')
%     %%%% plot this model
%     plot(state.time_myr,state.P/pars.P0,'b','displayname','P')
%     plot(state.time_myr,state.N/pars.N0,'g','displayname','N')
%     %%%% Title
%     title('Nutrient reservoirs')
%     %%%% legend
%     l = legend ;
%     set(l,'fontsize',6)
%     set(l,'edgecolor','none')
%     set(l,'location','northwest')
%     
%     %%%% Forg and Fpy ratos
%     subplot(4,5,8)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('f_{org}, f_{py}')
%     %%%% plot this model
%     plot(state.time_myr,state.mocb ./ (state.mocb + state.mccb),'k','displayname','f_{org}')
%     %%%% plot fpy
%     plot(state.time_myr, state.mpsb ./ (state.mpsb + state.mgsb),'m','displayname','f_{py}')
%     %%%% legend
%     l = legend ;
%     set(l,'fontsize',6)
%     set(l,'edgecolor','none')
%     set(l,'location','northwest')
%     
%     %%%% d13C record
%     subplot(4,5,9)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('\delta^{13}C_{carb}')
%     %%%% plot data comparison
%     plot(d13c_x,d13c_y,'.-','color',[0.8 0.8 0.8])
%     %%%% plot this model
%     plot(state.time_myr,state.delta_mccb,'k')
% 
%     %%%% d34S record
%     subplot(4,5,10)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('\delta^{34}S_{sw}')
%     %%%% plot data comparison
%     plot(d34s_x,d34s_y,'.-','color',[0.8 0.8 0.8])
%     %%%% plot this model
%     plot(state.time_myr,state.d34s_S,'k')
% 
%     %%%% Ocean 87Sr/86Sr 
%     subplot(4,5,11)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     ylim([0.706 0.71])
%     xlabel('Time (Ma)')
%     ylabel('^{87}Sr/^{86}Sr seawater')
%     %%%% plot data comparison
%     plot(sr_x,sr_y,'.-','color',[0.8 0.8 0.8])
%     %%%% plot this model
%     plot(state.time_myr,state.delta_OSr,'k')
% 
%     %%%% SO4
%     subplot(4,5,12)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('Marine SO_{4} (mM)')
%     %%%% plot this model
%     plot(state.time_myr,(state.S./pars.S0)*28,'k')
% 
%     %%%% O2 (%) 
%     subplot(4,5,13)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('Atmospheric O_{2} (%)')
%     %%%% plot this model
%     plot(state.time_myr,state.mrO2.*100,'k')
% 
%     %%%% CO2ppm
%     subplot(4,5,14)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     ylim([1.5 4.5])
%     yticks([1 2 3 4])
%     yticklabels({'10','100','1000','10,000'})
%     xlabel('Time (Ma)')
%     ylabel('Atmospheric CO_{2} (ppm)')
%     %%%% plot this model
%     plot(state.time_myr,log10(state.RCO2.*280),'k')
% 
%     %%%% TEMP
%     subplot(4,5,15)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     %ylim([5 40])
%     xlabel('Time (Ma)')
%     ylabel('GAST (C)')
%     %%%% plot this model
%     plot(state.time_myr,state.tempC,'k')
% 
%     
%     %%%% DOC res
%     subplot(4,5,16)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('marine boron (normalized)')
%     %%%% plot this model
%     plot(state.time_myr,state.B/pars.B0,'k')
%     ylim([0 max(state.B)/pars.B0]);
%    
%     %%%% DOC oxidation
%     subplot(4,5,17)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('\delta^1^1B (seawater)')
%     %%%% plot this model
%     plot(state.time_myr,state.d11B,'k')
%     ylim([0 max(state.d11B)]);
%    
% 
%     %%%% ANOX
%     subplot(4,5,18)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('ANOX')
%     %%%% plot this model
%     plot(state.time_myr,state.ANOX,'k')
%     
%     
% %     %%%% 
% %     subplot(4,5,19)
% %     hold on
% %     box on
% %     xlim(pars.plotrange)
% %     xlabel('Time (Ma)')
% %     ylabel('[U]')
% %     %%%% plot this model
% %     plot(state.time_myr,state.U,'k')
% 
%     %%%% D13C other reservoirs
%     subplot(4,5,19)
%     hold on
%     box on
%     xlim([pars.whenstart/1e6 pars.whenend/1e6])
%     xlabel('Time (Ma)')
%     ylabel('d13c C and S crust')
%     %%%% plot this model
%     plot(state.time_myr,state.delta_G,'k','displayname','deltaG')
%     plot(state.time_myr,state.delta_C,'c','displayname','deltaC')
%     %%%% D34S other reservoirs (same fig)
%     plot(state.time_myr,state.delta_PYR,'r--','displayname','deltaPYR')
%     plot(state.time_myr,state.delta_GYP,'g--','displayname','deltaGYP')
%     %%%% legend
%     l = legend ;
%     set(l,'fontsize',6)
%     set(l,'edgecolor','none')
%     set(l,'location','northwest')
%     
%     %%%% 
%     subplot(4,5,20)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('\delta^{238}U')
%     %%%% plot this model
%     plot(state.time_myr,state.d238U_sw,'k')
% %     
    LIPCO2cumul=cumsum(state.LIPCO2);
    disp('total CO_2 in');
    disp(LIPCO2cumul(length(LIPCO2cumul)));
    LIPCH4cumul=cumsum(state.LIPCH4);
    disp('total CH_4 in');
    disp(LIPCH4cumul(length(LIPCH4cumul)));
%     
%     figure
%     %%%% d13C record
%     subplot(3,1,1)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('\delta^{13}C_{carb}')
%     %%%% plot data comparison
%     plot(Clemensages,Clemensd13c,'x')
%     %%%% plot this model
%     plot(state.time_myr,state.delta_mccb)
%     legend('data','model')
%     title({'input \delta^1^3C= '+string(pars.d13CLIP)+', greenhouse inputs and \delta^1^3C data'})
%     
%     subplot(3,1,2)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     %plot(state.time_myr,state.LIPCO2)
%     plot(state.time_myr,LIPCO2cumul)
%     ylabel('cumulative CO_2 input');
%     %legend('flux (molyr^-^1)','cumulative (mol)');
%     subplot(3,1,3)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     %plot(state.time_myr,state.LIPCH4)
%     plot(state.time_myr,LIPCH4cumul)
%     %plot(state.time_myr,LIPCO2cumul)
%     ylabel('cumulative CH_4 input (mol)');
%     %legend('flux (molyr^-^1)','cumulative (mol)');
%     
%     figure
%     subplot(3,1,1)
%     title({'input \delta^1^3C= '+string(pars.d13CLIP)+', CO_2, pH, \delta^1^1B'})
%     hold on
%     box on
%     xlim(pars.plotrange)
%     %plot(state.time_myr,state.pCO2in)
%     plot(state.time_myr,state.pCO2out)
%     xlabel('Time (Ma)')
%     ylabel('pCO_2 (\mu atm)')
%     %legend('in','out');
%     subplot(3,1,2)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     plot(state.time_myr,state.pH)
%     xlabel('Time (Ma)')
%     ylabel('pH')
%     ylim([7 9])
%     
%     subplot(3,1,3)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('\delta^1^1B ')
%     plot(state.time_myr,state.d11B,'linewidth',2.0)
%     plot(state.time_myr,state.d11Bcarb,'linewidth',2.0)
%     plot(state.time_myr,state.d11B_micritic_S,'x','linewidth',1,'markersize',1)
%     plot(state.time_myr,state.d11B_micritic_P,'x','linewidth',1,'markersize',1)
%     plot(state.time_myr,state.d11B_brachio_S,'x','linewidth',1,'markersize',1)
%     plot(state.time_myr,state.d11B_brachio_P,'x','linewidth',0.5,'markersize',0.5)
%     legend('model seawater','model carbonate',...
%         'micritic, Spain','micritic, Portugal',...
%         'brachiopod, Spain','brachiopod, Portugal') 
%     ylim([0 40])
% 
%     figure
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('\delta^1^1B ')
%     plot(state.time_myr,state.d11B,'linewidth',2.0)
%     plot(state.time_myr,state.d11Bcarb,'linewidth',2.0)
%     plot(state.time_myr,state.d11B_micritic_S,'x','linewidth',1,'markersize',1)
%     plot(state.time_myr,state.d11B_micritic_P,'x','linewidth',1,'markersize',1)
%     plot(state.time_myr,state.d11B_brachio_S,'x','linewidth',1,'markersize',1)
%     plot(state.time_myr,state.d11B_brachio_P,'x','linewidth',1,'markersize',1)
%     legend('model seawater','model carbonate',...
%         'micritic, Spain','micritic, Portugal',...
%         'brachiopod, Spain','brachiopod, Portugal') 
%     ylim([0 40])
%     title({'input \delta^1^3C= '+string(pars.d13CLIP)+', \delta^1^1B'})
% 
%     
%     figure
%     subplot(5,1,1)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     plot(state.time_myr,state.pH,'linewidth',2.0)
%     %plot(state.time_myr,state.Klochko)
%     plot(state.time_myr,state.pKB,'linewidth',2.0)
%     legend('model pH','model pKB')
%     ylabel('pH')
%     ylim([5 9])
%     %title({'input \delta^1^3C= '+string(pars.d13CLIP)+', pH inversions'})
%     title('model pH')
%     subplot(5,1,2)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     plot(state.time_myr,state.Klochko,'g','linewidth',2.0)
%     plot(state.time_myr,state.Klochko_M_S,'ro','linewidth',0.05,'markersize',4.0)
%     plot(state.time_myr,state.Klochko_M_P,'bo','linewidth',0.05,'markersize',4.0)
%     legend('model BOH_4^-','Spain','Portugal')
%     title('Klochko')
%     ylim([5 9])
%     subplot(5,1,3)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     %plot(state.time_myr,state.Lecuyer_M_S)
%     plot(state.time_myr,state.Lecuyer_B_S,'rx','linewidth',0.5,'markersize',4.0)
%     %plot(state.time_myr,state.Lecuyer_M_P)
%     plot(state.time_myr,state.Lecuyer_B_P,'bx','linewidth',0.5,'markersize',4.0)
%     legend('Spain','Portugal')
%     %legend('micritic, Spain','brachiopod, Spain','micritic, Portugal','brachiopod, Portugal')
%     ylim([5 9])
%     title('Lecuyer')
%     subplot(5,1,4)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     %plot(state.time_myr,state.Lemarchand_M_S)
%     plot(state.time_myr,state.Lemarchand_B_S,'rx','linewidth',0.5,'markersize',4.0)
%     %plot(state.time_myr,state.Lemarchand_M_P)
%     plot(state.time_myr,state.Lemarchand_B_P,'bx','linewidth',0.5,'markersize',4.0)
%     ylim([5 9])
%     legend('Spain','Portugal')
%     %legend('micritic, Spain','brachiopod, Spain','micritic, Portugal','brachiopod, Portugal')
%     title('Lemarchand')
%     subplot(5,1,5)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     %plot(state.time_myr,state.Jurikova_M_S)
%     plot(state.time_myr,state.Jurikova_B_S,'rx','linewidth',0.5,'markersize',4.0)
%     %plot(state.time_myr,state.Jurikova_M_P)
%     plot(state.time_myr,state.Jurikova_B_P,'bx','linewidth',0.5,'markersize',4.0)
%     ylim([5 9])
%     legend('Spain','Portugal')
%     %legend('micritic, Spain','brachiopod, Spain','micritic, Portugal','brachiopod, Portugal')
%     title('Jurikova')
% %     
%     figure
%     subplot(1,3,1)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     plot(state.time_myr,state.pH,'linewidth',1.0)
%     %plot(state.time_myr,state.Klochko)
%     plot(state.time_myr,state.pKB,'linewidth',1.0)
%     %plot(state.time_myr,state.Klochko)
%     legend('model pH','model pKB');%,'model BOH_4^-')
%     ylabel('pH')
%     ylim([6 8.75])
%     title('A. MODEL')
%     subplot(1,3,2)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     %plot(state.time_myr,state.Klochko)
%     plot(state.time_myr,state.Klochko_M_S,'r','linewidth',1.0)
%     plot(state.time_myr,state.Klochko_M_P,'r--','linewidth',1.0)
%     legend('Klochko (Spain)','Klochko (Portugal)')
%     title('B. MICRITIC DATA')
%     ylim([6 8.75])
%     subplot(1,3,3)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     plot(state.time_myr,state.Lecuyer_B_S,'b','linewidth',1.0)
%     plot(state.time_myr,state.Lecuyer_B_P,'b--','linewidth',1.0)
%     plot(state.time_myr,state.Lemarchand_B_S,'g','linewidth',1.0)
%     plot(state.time_myr,state.Lemarchand_B_P,'g--','linewidth',1.0)
%     plot(state.time_myr,state.Jurikova_B_S,'m','linewidth',1.0)
%     plot(state.time_myr,state.Jurikova_B_P,'m--','linewidth',1.0)
%     plot(state.time_myr,state.Penman_B_P,'c','linewidth',1.0)
%     plot(state.time_myr,state.Penman_B_S,'c--','linewidth',1.0)
%     ylim([6 8.75])
%     legend('Lecuyer (Spain)','Lecuyer (Portugal)','Lemarchand (Spain)','Lemarchand (Portugal)',...
%         'Jurikova (Spain)','Jurikova (Portugal)','Penman (Spain)','Penman (Portugal)')
%     title('C. BRACHIOPOD DATA')
% 
%     figure
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     plot(state.time_myr,state.pH,'k','linewidth',2.0)
%     %plot(state.time_myr,state.Klochko,'m','linewidth',2.0)
%     %plot(state.time_myr,state.pKB,'k--','linewidth',1.0)
%     plot(state.time_myr,state.Klochko_M_S,'r','linewidth',2.0)
%     plot(state.time_myr,state.Klochko_M_P,'r--','linewidth',2.0)
%     %plot(state.time_myr,state.Lecuyer_B_S,'b','linewidth',1.0)
%     %plot(state.time_myr,state.Lecuyer_B_P,'b--','linewidth',1.0)
%     plot(state.time_myr,state.Lemarchand_B_S,'g','linewidth',2.0)
%     plot(state.time_myr,state.Lemarchand_B_P,'g--','linewidth',2.0)
%     plot(state.time_myr,state.Jurikova_B_S,'b','linewidth',2.0)
%     plot(state.time_myr,state.Jurikova_B_P,'b--','linewidth',2.0)
%     ylim([6.75 8.75])
%     ylabel('pH')
%     legend('model pH','Micritic (Klochko, Spain)','Micritic (Klochko, Portugal)',...
%        'Brachiopod (Lemarchand, Spain)',...
%        'Brachiopod(Lemarchand, Portugal)','Brachiopod (Jurikova, Spain)','Brachiopod (Jurikova, Portugal)')
% 
%     
%     
%     
%     
%     figure
%     title({'input \delta^1^3C= '+string(pars.d13CLIP)+', temperature'})
%     hold on
%     box on
%     plot(state.time_myr,state.tempC,'linewidth',2.0)
%     plot(state.time_myr,state.tempCsurf,'linewidth',2.0)
%     plot(state.time_myr,state.T_Hansen)
%     plot(state.time_myr,state.T_Craig)
%     plot(state.time_myr,state.T_AA)
%     plot(state.time_myr,state.T_Epstein)
%     plot(state.time_myr,state.T_LM)
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('Temperature (celsius)')
%     legend('model (global average)','model (sea surface, low latitude)','\delta^1^8O inversion (Hansen)',...
%         '\delta^1^8O inversion (Craig)','\delta^1^8O inversion (Andersen & Arthur)',...
%         '\delta^1^8O inversion (Epstein)','\delta^1^8O inversion (Leng & Marshal)')
%     ylim([0 45])
%     
    figure
    subplot(4,2,1)
    hold on
    box on
    xlim(pars.plotrange)
    xlabel('Time (Ma)')
    ylabel('\delta^{13}C_{carb}')
    %%%% plot data comparison
    plot(Clemensages,Clemensd13c,'x','linewidth',1.0,'markersize',4.0)
    %%%% plot this model
    plot(state.time_myr,state.delta_mccb,'linewidth',1.0)
    legend('data','model','location','southoutside')
    l = legend ;
    %set(l,'fontsize',6)
    title('A. \delta^1^3C')
    %title({'A. input \delta^1^3C= '+string(pars.d13CLIP)+', greenhouse inputs and \delta^1^3C data'})
    ylim([-1 7])
    subplot(4,2,2)
            hold on
    box on
    xlim(pars.plotrange)
    xlabel('Time (Ma)')
    ylabel('\delta^1^1B ')
    plot(state.time_myr,state.d11B,'k','linewidth',2.0)
    plot(state.time_myr,state.d11Bcarb,'g','linewidth',2.0)
    plot(Tinaage_micritic_S,Tinad11B_micritic_S,'xr','linewidth',1,'markersize',6)
    plot(Tinaage_micritic_P,Tinad11B_micritic_P,'or','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_S,Tinad11B_brachio_S,'xb','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_P,Tinad11B_brachio_P,'ob','linewidth',1,'markersize',6)
%     
%     
%     plot(state.time_myr,state.d11B_micritic_S,'xr','linewidth',0.5,'markersize',3)
%     plot(state.time_myr,state.d11B_micritic_P,'or','linewidth',0.5,'markersize',3)
%     plot(state.time_myr,state.d11B_brachio_S,'xb','linewidth',0.5,'markersize',3)
%     plot(state.time_myr,state.d11B_brachio_P,'ob','linewidth',0.5,'markersize',3)
    legend('model seawater','model carbonate',...
        'data, micritic (M), Spain (S)','data, micritic (M), Portugal (P)',...
        'data, brachiopod (B), Spain (S)','data, brachiopod (B), Portugal (P)','location','southoutside') 
        l3 = legend ;
    set(l3,'fontsize',6)
    ylim([5 40])
    title('B. \delta^1^1B')

% 
% 
%         hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('\delta^1^1B ')
%     %plot(state.time_myr,state.d11B,'k','linewidth',2.0)
%     plot(state.time_myr,state.d11Bcarb,'g','linewidth',2.0)
%     plot(Tinaage_micritic_S,Tinad11B_micritic_S,'xr','linewidth',1,'markersize',6)
%     plot(Tinaage_micritic_P,Tinad11B_micritic_P,'or','linewidth',1,'markersize',6)
%     plot(Tinaage_brachio_S,Tinad11B_brachio_S,'xb','linewidth',1,'markersize',6)
%     plot(Tinaage_brachio_P,Tinad11B_brachio_P,'ob','linewidth',1,'markersize',6)
% %     
% %     
% %     plot(state.time_myr,state.d11B_micritic_S,'xr','linewidth',0.5,'markersize',3)
% %     plot(state.time_myr,state.d11B_micritic_P,'or','linewidth',0.5,'markersize',3)
% %     plot(state.time_myr,state.d11B_brachio_S,'xb','linewidth',0.5,'markersize',3)
% %     plot(state.time_myr,state.d11B_brachio_P,'ob','linewidth',0.5,'markersize',3)
%     legend('model carbonate',...
%         'data, micritic (M), Spain (S)','data, micritic (M), Portugal (P)',...
%         'data, brachiopod (B), Spain (S)','data, brachiopod (B), Portugal (P)','location','southoutside') 
%         l = legend ;
%     %set(l,'fontsize',6)
%     %set(l,'edgecolor','none')
%     ylim([7.5 17.5])
%     title('B. \delta^1^1B')
    subplot(4,2,3)
    hold on
    box on
    xlim(pars.plotrange)
    xlabel('Time (Ma)')
    %plot(state.time_myr,state.LIPCO2)
    plot(state.time_myr,LIPCO2cumul,'linewidth',1.0)
    plot(state.time_myr,LIPCH4cumul,'linewidth',1.0)
    ylabel('cumulative input (mol)');
    %ylabel('flux (molyr^-^1)');
    disp(string(pars.d13CLIP))
    string1='CO_2, \delta^1^3C='+string(pars.d13CLIP);
    string2='CH_4, \delta^1^3C='+string(pars.d13CCH4);
    legend(string1,string2,'location','southoutside')
        l = legend ;
    %set(l,'fontsize',6)
    %set(l,'edgecolor','none')
%     legend({'CO_2, \delta^1^3C='+string(pars.d13CLIP)},...
%         {'CH_4, \delta^1^3C='+string(pars.d13CCH4)})
    title('C. Greenhouse inputs (cumulative)')
    ylim([0 8e16])
    subplot(4,2,4)
    hold on
    box on
    xlim(pars.plotrange)
    xlabel('Time (Ma)')
    %plot(state.time_myr,state.LIPCO2)
    plot(state.time_myr,state.LIPCO2,'linewidth',1.0)
    plot(state.time_myr,state.LIPCH4,'linewidth',1.0)
    %ylabel('cumulative input (mol)');
    ylabel('flux (molyr^-^1)');
    disp(string(pars.d13CLIP))
    string1='CO_2, \delta^1^3C='+string(pars.d13CLIP);
    string2='CH_4, \delta^1^3C='+string(pars.d13CCH4);
    legend(string1,string2,'location','southoutside')
        l = legend ;
    %set(l,'fontsize',6)
    ylim([0 15e13])
   
%     legend({'CO_2, \delta^1^3C='+string(pars.d13CLIP)},...
%         {'CH_4, \delta^1^3C='+string(pars.d13CCH4)})
    title('D. Greenhouse inputs (fluxes)')
    
%
 subplot(4,2,5)
% hold on
% box on
% xlim(pars.plotrange)
% xlabel('Time (Ma)')
% plot(state.time_myr,state.pH,'k','linewidth',2.0)
% %plot(state.time_myr,state.Klochko,'m','linewidth',2.0)
% plot(state.time_myr,state.pKB,'k--','linewidth',1.0)
% plot(state.time_myr,state.Klochko_M_S,'r','linewidth',1,'markersize',0.5)
% plot(state.time_myr,state.Klochko_M_P,'r--','linewidth',1,'markersize',0.5)
% plot(state.time_myr,state.Lecuyer_B_S,'b','linewidth',1,'markersize',0.5)
% plot(state.time_myr,state.Lecuyer_B_P,'b--','linewidth',1,'markersize',0.5)
% plot(state.time_myr,state.Lemarchand_B_S,'g','linewidth',1,'markersize',0.5)
% plot(state.time_myr,state.Lemarchand_B_P,'g--','linewidth',1,'markersize',0.5)
% plot(state.time_myr,state.Jurikova_B_S,'y','linewidth',1,'markersize',0.5)
% plot(state.time_myr,state.Jurikova_B_P,'y--','linewidth',1,'markersize',0.5)
% plot(state.time_myr,state.Penman_B_S,'m','linewidth',1,'markersize',0.5)
% plot(state.time_myr,state.Penman_B_P,'m--','linewidth',1,'markersize',0.5)
% ylim([7 9])
% ylabel('pH')
% legend('model pH','model pKB','Klochko, MS','Klochko MP',...
%    'Lecuyer BS','Lecuyer BP',...
%    'Lemarchand BS','Lemarchand BP',...
%    'Jurikova BS','Jurikova BP',...
%    'Penman BS','Penman BP','location','southoutside')
%    l = legend ;
% set(l,'fontsize',6)
% title('C. pH')

    hold on
    box on
    xlim(pars.plotrange)
    xlabel('Time (Ma)')
    plot(state.time_myr,state.pH,'k','linewidth',2.0)
    %plot(state.time_myr,state.Klochko,'m','linewidth',2.0)
    plot(state.time_myr,state.pKB,'k--','linewidth',2.0)
    plot(Tinaage_micritic_S,Klochko_M_S_fixed,'rx','linewidth',1,'markersize',6)
    plot(Tinaage_micritic_P,Klochko_M_P_fixed,'ro','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_S,Lecuyer_B_S_fixed,'bx','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_P,Lecuyer_B_P_fixed,'bo','linewidth',1,'markersize',6)
    %plot(Tinaage_brachio_S,Lemarchand_B_S_fixed,'gx','linewidth',1,'markersize',6)
    %plot(Tinaage_brachio_P,Lemarchand_B_P_fixed,'go','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_S,Jurikova_B_S_fixed,'yx','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_P,Jurikova_B_P_fixed,'yo','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_S,Penman_B_S_fixed,'mx','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_P,Penman_B_P_fixed,'mo','linewidth',1,'markersize',6)
    ylim([6.5 9])
    %ylim([7 9])
    ylabel('pH')
    legend('model pH','model pKB','Klochko, MS','Klochko MP',...
       'Lecuyer BS','Lecuyer BP',...%'Lemarchand BS','Lemarchand BP',...
       'Jurikova BS','Jurikova BP',...
       'Penman BS','Penman BP','location','southoutside')
       l2 = legend ;
    set(l2,'fontsize',6)
    title('E. pH')



    subplot(4,2,6)
    hold on
    box on
    plot(state.time_myr,state.RCO2,'linewidth',1.0)
    plot(state.time_myr,100*state.ANOX,'linewidth',1.0)
    xlim(pars.plotrange)
    xlabel('Time (Ma)')
    ylabel('relative value')
    legend('relative atmospheric CO_2','anoxia (%)','location','southoutside')
    title('F. ocean anoxia and atmospheric CO_2')
    ylim([0 60])
    subplot(4,2,7)
    hold on
    box on
    plot(state.time_myr,state.tempC,'linewidth',2.0)
    %plot(state.time_myr,state.tempCsurf,'linewidth',2.0)
    plot(state.time_myr,state.T_Hansen,'--','linewidth',1.0)
    plot(state.time_myr,state.T_Craig,'--','linewidth',1.0)
    plot(state.time_myr,state.T_AA,'--','linewidth',1.0)
    plot(state.time_myr,state.T_Epstein,'--','linewidth',1.0)
    plot(state.time_myr,state.T_LM,'--','linewidth',1.0)
    xlim(pars.plotrange)
    xlabel('Time (Ma)')
    ylabel('Temperature (celsius)')
    legend('model (global average)','\delta^1^8O Hansen',...
        '\delta^1^8O Craig','\delta^1^8O Andersen & Arthur',...
        '\delta^1^8O Epstein','\delta^1^8O Leng & Marshal','location','southoutside')
    l = legend ;
    %set(l,'fontsize',6)
        
    ylim([5 38])
    title('G. temperature')
    
    subplot(4,2,8)
    hold on
    box on
    xlim(pars.plotrange)
    xlabel('Time (Ma)')
    ylabel('Relative size')
    %%%% plot this model
    plot(state.time_myr,state.G/pars.G0,'displayname','organic C','linewidth',1.0)
    plot(state.time_myr,state.C/pars.C0,'displayname','carbonate C','linewidth',1.0)
    plot(state.time_myr,state.VEG,'displayname','land biota','linewidth',1.0)
    plot(state.time_myr,state.P/pars.P0,'displayname','P','linewidth',1.0)
    plot(state.time_myr,state.N/pars.N0,'displayname','N','linewidth',1.0)
    plot(state.time_myr,(state.S/pars.S0),'displayname','S','linewidth',1.0)
    plot(state.time_myr,(state.O/pars.O0),'displayname','O','linewidth',1.0)
    %%%% Title
    title('H. Reservoirs')
    %%%% legend
    l = legend ;
    ylim([0 5])
    %set(l,'fontsize',6)
    
    
    
    
    
%     
%     figure
%     hold on
%     box on
%     plot(state.time_myr,state.Jurikova_borate_B_P)
%     plot(state.time_myr,state.Jurikova_borate_B_S)
%     %plot(state.time_myr,state.Jurikova_B_S,'m','linewidth',1.0)
%     %plot(state.time_myr,state.Jurikova_B_P,'m--','linewidth',1.0)
%     
% 
%    
% HERE
%     
%     figure
%     subplot(1,3,1)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('\delta^{13}C_{carb}')
%     %%%% plot data comparison
%     plot(Clemensages,Clemensd13c,'x','linewidth',1.0,'markersize',4.0)
%     %%%% plot this model
%     plot(state.time_myr,state.delta_mccb,'linewidth',1.0)
%     legend('data','model','location','southoutside')
%         l = legend ;
%     set(l,'fontsize',6)
%     title('A. \delta^1^3C')
%     subplot(1,3,2)
%         hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('\delta^1^1B ')
%     plot(state.time_myr,state.d11B,'k','linewidth',2.0)
%     plot(state.time_myr,state.d11Bcarb,'g','linewidth',2.0)
%     plot(Tinaage_micritic_S,Tinad11B_micritic_S,'xr','linewidth',1,'markersize',6)
%     plot(Tinaage_micritic_P,Tinad11B_micritic_P,'or','linewidth',1,'markersize',6)
%     plot(Tinaage_brachio_S,Tinad11B_brachio_S,'xb','linewidth',1,'markersize',6)
%     plot(Tinaage_brachio_P,Tinad11B_brachio_P,'ob','linewidth',1,'markersize',6)
% %     
% %     
% %     plot(state.time_myr,state.d11B_micritic_S,'xr','linewidth',0.5,'markersize',3)
% %     plot(state.time_myr,state.d11B_micritic_P,'or','linewidth',0.5,'markersize',3)
% %     plot(state.time_myr,state.d11B_brachio_S,'xb','linewidth',0.5,'markersize',3)
% %     plot(state.time_myr,state.d11B_brachio_P,'ob','linewidth',0.5,'markersize',3)
%     legend('model seawater','model carbonate',...
%         'data, micritic (M), Spain (S)','data, micritic (M), Portugal (P)',...
%         'data, brachiopod (B), Spain (S)','data, brachiopod (B), Portugal (P)','location','southoutside') 
%         l = legend ;
%     set(l,'fontsize',6)
%     %ylim([7.5 17.5])
%     title('B. \delta^1^1B')
%     subplot(1,3,3)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     plot(state.time_myr,state.pH,'k','linewidth',2.0)
%     %plot(state.time_myr,state.Klochko,'m','linewidth',2.0)
%     plot(state.time_myr,state.pKB,'k--','linewidth',1.0)
%     plot(state.time_myr,state.Klochko_M_S,'r','linewidth',1,'markersize',0.5)
%     plot(state.time_myr,state.Klochko_M_P,'r--','linewidth',1,'markersize',0.5)
%     plot(state.time_myr,state.Lecuyer_B_S,'b','linewidth',1,'markersize',0.5)
%     plot(state.time_myr,state.Lecuyer_B_P,'b--','linewidth',1,'markersize',0.5)
%     plot(state.time_myr,state.Lemarchand_B_S,'g','linewidth',1,'markersize',0.5)
%     plot(state.time_myr,state.Lemarchand_B_P,'g--','linewidth',1,'markersize',0.5)
%     plot(state.time_myr,state.Jurikova_B_S,'y','linewidth',1,'markersize',0.5)
%     plot(state.time_myr,state.Jurikova_B_P,'y--','linewidth',1,'markersize',0.5)
%     plot(state.time_myr,state.Penman_B_S,'m','linewidth',1,'markersize',0.5)
%     plot(state.time_myr,state.Penman_B_P,'m--','linewidth',1,'markersize',0.5)
%     ylim([7 9])
%     ylabel('pH')
%     legend('model pH','model pKB','Klochko, MS','Klochko MP',...
%        'Lecuyer BS','Lecuyer BP',...
%        'Lemarchand BS','Lemarchand BP',...
%        'Jurikova BS','Jurikova BP',...
%        'Penman BS','Penman BP','location','southoutside')
%        l = legend ;
%     set(l,'fontsize',6)
%     title('C. pH')
%     
    
    
 %HERE   
% 
%     
%     
%     legend('model pH','micritic (Klochko, Spain)','micritic (Klochko, Portugal)',...
%        'brachiopod (Lecuyer, Spain)','brachiopod (Lecuyer, Portugal)',...
%        'brachiopod (Lemarchand, Spain)','brachiopod(Lemarchand, Portugal)',...
%        'brachiopod (Jurikova, Spain)','brachiopod (Jurikova, Portugal)',...
%        'brachiopod (Penman, Spain)','brachiopod (Penman, Portugal)','location','southoutside')
%        
    
    


    figure
    subplot(1,3,1)
    hold on
    box on
    xlim(pars.plotrange)
    xlabel('Time (Ma)')
    ylabel('\delta^{13}C_{carb}')
    %%%% plot data comparison
    plot(Clemensages,Clemensd13c,'x','linewidth',1,'markersize',6)
    %%%% plot this model
    plot(state.time_myr,state.delta_mccb,'linewidth',2.0)
    legend('data','model','location','southoutside')
        l1 = legend ;
    set(l1,'fontsize',6)
    %title({'A. input \delta^1^3C= '+string(pars.d13CLIP)+', greenhouse inputs and \delta^1^3C data'})
    title('A. \delta^1^3C')
    subplot(1,3,2)
        hold on
    box on
    xlim(pars.plotrange)
    xlabel('Time (Ma)')
    ylabel('\delta^1^1B ')
    plot(state.time_myr,state.d11B,'k','linewidth',2.0)
    plot(state.time_myr,state.d11Bcarb,'g','linewidth',2.0)
    plot(Tinaage_micritic_S,Tinad11B_micritic_S,'xr','linewidth',1,'markersize',6)
    plot(Tinaage_micritic_P,Tinad11B_micritic_P,'or','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_S,Tinad11B_brachio_S,'xb','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_P,Tinad11B_brachio_P,'ob','linewidth',1,'markersize',6)
%     
%     
%     plot(state.time_myr,state.d11B_micritic_S,'xr','linewidth',0.5,'markersize',3)
%     plot(state.time_myr,state.d11B_micritic_P,'or','linewidth',0.5,'markersize',3)
%     plot(state.time_myr,state.d11B_brachio_S,'xb','linewidth',0.5,'markersize',3)
%     plot(state.time_myr,state.d11B_brachio_P,'ob','linewidth',0.5,'markersize',3)
    legend('model seawater','model carbonate',...
        'data, micritic (M), Spain (S)','data, micritic (M), Portugal (P)',...
        'data, brachiopod (B), Spain (S)','data, brachiopod (B), Portugal (P)','location','southoutside') 
        l3 = legend ;
    set(l3,'fontsize',6)
    %ylim([7.5 17.5])
    title('B. \delta^1^1B')
    subplot(1,3,3)
    hold on
    box on
    xlim(pars.plotrange)
    xlabel('Time (Ma)')
    plot(state.time_myr,state.pH,'k','linewidth',2.0)
    %plot(state.time_myr,state.Klochko,'m','linewidth',2.0)
    plot(state.time_myr,state.pKB,'k--','linewidth',2.0)
    plot(Tinaage_micritic_S,Klochko_M_S_fixed,'rx','linewidth',1,'markersize',6)
    plot(Tinaage_micritic_P,Klochko_M_P_fixed,'ro','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_S,Lecuyer_B_S_fixed,'bx','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_P,Lecuyer_B_P_fixed,'bo','linewidth',1,'markersize',6)
    %plot(Tinaage_brachio_S,Lemarchand_B_S_fixed,'gx','linewidth',1,'markersize',6)
    %plot(Tinaage_brachio_P,Lemarchand_B_P_fixed,'go','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_S,Jurikova_B_S_fixed,'yx','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_P,Jurikova_B_P_fixed,'yo','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_S,Penman_B_S_fixed,'mx','linewidth',1,'markersize',6)
    plot(Tinaage_brachio_P,Penman_B_P_fixed,'mo','linewidth',1,'markersize',6)
    %ylim([6.75 8.75])
    %ylim([7 9])
    ylabel('pH')
    legend('model pH','model pKB','Klochko, MS','Klochko MP',...
       'Lecuyer BS','Lecuyer BP',...%'Lemarchand BS','Lemarchand BP',...
       'Jurikova BS','Jurikova BP',...
       'Penman BS','Penman BP','location','southoutside')
       l2 = legend ;
    set(l2,'fontsize',6)
    title('C. pH')
    
    %close all
     
    % subplot(1,3,3)
% 
%     figure
%     hold on
%     box on
%     plot(Tinaage_micritic_S,Tinad11B_micritic_S,'xr','linewidth',2,'markersize',6)
%     plot(Tinaage_micritic_P,Tinad11B_micritic_P,'xb','linewidth',2,'markersize',6)
%     plot(Tinaage_brachio_S,Tinad11B_brachio_S,'xg','linewidth',2,'markersize',6)
%     plot(Tinaage_brachio_P,Tinad11B_brachio_P,'xk','linewidth',2,'markersize',6)
%     plot(Tinaage_micritic_S,d11B_SM,'or','linewidth',2,'markersize',6)
%     plot(Tinaage_micritic_P,d11B_PM,'ob','linewidth',2,'markersize',6)
%     plot(Tinaage_brachio_S,d11B_S,'og','linewidth',2,'markersize',6)
%     plot(Tinaage_brachio_P,d11B_P,'ok','linewidth',2,'markersize',6)
%     xlabel('age')
%     ylabel('\delta^1^1B data')
%     legend('micritic, spain','micritic, portugal','brachiopod, spain','brachiopod, portugal',...
%         'nearest model d11B (MS)','nearest model d11B (MP)','nearest model d11B (BS)','nearest model d11B (BP)');
%         
%     
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
%     
%     
%     figure
%     subplot(6,1,1)
%     title({'input \delta^1^3C= '+string(pars.d13CLIP)+', \delta^1^3C'})
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('\delta^{13}C_{carb}')
%     %%%% plot data comparison
%     plot(Clemensages,Clemensd13c,'x')
%     %%%% plot this model
%     plot(state.time_myr,state.delta_mccb,'linewidth',2.0)
%     %title('\delta^1^3C')
%     legend('data','model')
%     subplot(6,1,2)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     %plot(state.time_myr,state.LIPCH4)
%     plot(state.time_myr,LIPCH4cumul,'linewidth',2.0)
%     plot(state.time_myr,LIPCO2cumul,'linewidth',2.0)
%     ylabel('cumulative input (mol)');
%     legend('CH_4','CO_2');
%     title('greenhouse gas inputs')
%     subplot(6,1,3)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('\delta^1^1B ')
%     %plot(state.time_myr,state.d11B)
%     plot(state.time_myr,state.d11Bcarb,'linewidth',2.0)
%     plot(state.time_myr,state.d11B_micritic_S,'x','linewidth',0.1)
%     plot(state.time_myr,state.d11B_micritic_P,'x','linewidth',0.1)
%     plot(state.time_myr,state.d11B_brachio_S,'x','linewidth',0.1)
%     plot(state.time_myr,state.d11B_brachio_P,'x','linewidth',0.1)
%     legend('model carbonate',...
%         'micritic, Spain','micritic, Portugal',...
%         'brachiopod, Spain','brachiopod, Portugal') 
%     ylim([0 20])
%     title('carbonate \delta^1^1B')
%     subplot(6,1,4)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     ylim([6 9]);
%     ylabel('pH');
%     plot(state.time_myr,state.pH,'linewidth',2.0)
%     plot(state.time_myr,state.Jurikova_M_S,'rx','linewidth',0.1)
%     plot(state.time_myr,state.Jurikova_B_S,'ro','linewidth',0.1)
%     plot(state.time_myr,state.Jurikova_M_P,'bx','linewidth',0.1)
%     plot(state.time_myr,state.Jurikova_B_P,'bo','linewidth',0.1)
%     legend('model','Jurikova inversion (micritic, Spain)','Jurikova inversion (brachiopod, Spain)',...
%         'Jurikova inversion (micritic, Portugal)','Jurikova inversion (brachiopod, Portugal)')
%     title('pH')
%     subplot(6,1,5)
%     hold on
%     box on
%     plot(state.time_myr,state.tempC,'linewidth',2.0)
%     plot(state.time_myr,state.tempCsurf,'linewidth',2.0)
%     plot(state.time_myr,state.T_Hansen,'x','linewidth',0.1)
%     plot(state.time_myr,state.T_Craig,'x','linewidth',0.1)
%     plot(state.time_myr,state.T_AA,'x','linewidth',0.1)
%     plot(state.time_myr,state.T_Epstein,'x','linewidth',0.1)
%     plot(state.time_myr,state.T_LM,'x','linewidth',0.1)
%     xlim(pars.plotrange)
%     ylim([0 45])
%     xlabel('Time (Ma)')
%     ylabel('Temperature (celsius)')
%     legend('model (global average)','model (sea surface, low latitude)','\delta^1^8O inversion (Hansen)',...
%         '\delta^1^8O inversion (Craig)','\delta^1^8O inversion (Andersen & Arthur)',...
%         '\delta^1^8O inversion (Epstein)','\delta^1^8O inversion (Leng & Marshal)')
%     title('temperature')
%     subplot(6,1,6)
%     hold on
%     box on
%     xlim(pars.plotrange)
%     xlabel('Time (Ma)')
%     ylabel('ANOX')
%     %%%% plot this model
%     plot(state.time_myr,state.ANOX,'linewidth',2.0)
%     ylim([0 0.1])
%     title('anoxia')
    

    %%%%% plotting script finished
    fprintf('Done: ')
    endtime = toc ;
    fprintf('time (s): %d \n', endtime )


end





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%   Cleanup workspace   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear stepnumber
clear u
clear numfields
clear trecords
clear finalrecord
clear field_names
clear n
clear veclength
clear xvec
clear yvec
clear endtime


%%%%% plotting script finished
fprintf('Done: ')
endtime = toc ;
fprintf('time (s): %d \n', endtime )
