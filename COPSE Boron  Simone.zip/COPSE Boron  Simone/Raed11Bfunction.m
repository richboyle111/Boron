function [dB4, dB3, cB4, cB3, pKb, BT, Kbval] = Raed11Bfunction(pH,T,S,Z,d11Bsw,Bnorm)

% This code was written by James Rae, University of St Andrews, to
% accompany Rae (2017), Boron isotopes in foraminifera: systematics,
% biomineralisation, and carbonate system reconstruction, AiG.  Please send
% any queries to jwbr@st-andrews.ac.uk.  Please cite reference above if
% using this code. 
%
% Calculates concentrations and isotopic compositions of boron molecules in
% seawater, at given temperature (C), salinity (psu), depth (m), d11Bsw
% (permil).
% Assumes modern [Mg] (52.8171 mol/kg), [Ca] (10.2821 mol/kg).
% Input vectors can either all be the same length, or one may vary with
% others set to a single value.
% Boron isotope calculations are based on correct mass balance equation
% treating each boron nuclide separately, given in Rae 2017 AiG. 
% Kb from Dickson (1990)
% Pressure correction of Kb uses formulation of Zeebe & Wolf-Gladrow
% (2001).  The coefficients are often misquoted.  The correct set are from
% Millero 1979 (recalulated from Culberson and Pytlowicz 1968), as given by
% CO2SYS and Rae et al. (2011) 
% Alpha from Klochko et al. (2006)

% EXAMPLE
% pH = [7.5; 8; 8.5]
% T = [25]
% S = [35]
% Z = [0]
% d11Bsw = [38]

% [dB4, dB3, cB4, cB3, pKb] = fnpHtod11B_d11Bsw(pH,T,S,Z,d11Bsw)
% dB4 =
% 
%    12.5378
%    16.0349
%    22.6862
% 
% 
% dB3 =
% 
%    40.0788
%    43.6710
%    50.5033
% 
% 
% cB4 =
% 
%    32.0066
%    87.2547
%   192.1307
% 
% 
% cB3 =
% 
%   400.5964
%   345.3482
%   240.4722
% 
% 
% pKb =
% 
%     8.5975
%     8.5975
%     8.5975

%% set up vectors

%Determine lengths of input vectors
vecsizes=[size(pH); size(T); size(S); size(Z); size(d11Bsw)];

ind = find(max(vecsizes));
samplesize = vecsizes(ind(1),:);

if length(unique(vecsizes))>2
	disp(' '); disp('*** INPUT ERROR: Input vectors must either: a) all be of same length, or b) all have length 1 except one longer vector. ***'); disp(' '); return
end
% allow for case where only change one variable - all others have set constant values
if max(vecsizes(1,:)) ==1
pH = pH*ones(samplesize);
end
if max(vecsizes(2,:)) ==1
T = T*ones(samplesize);
end
if max(vecsizes(3,:)) ==1
S = S*ones(samplesize);
end
if max(vecsizes(4,:)) ==1
Z = Z*ones(samplesize);
end
if max(vecsizes(5,:)) ==1
d11Bsw = d11Bsw*ones(samplesize);
end

%% constants
alpha       = 1.0272;
epsilon     = (alpha-1)*10^3;
BTref       = (0.0002414/10.811)*(35/1.80655)*10^6; %�1.62, from Lee (2010): B/Cl = 0.2414 and Sal/Cl = 1.80655 (Cox 1967)
R           = 83.14472;
Rstd        = 4.04367; %(951 ratio)

%% calculations
P           = Z/10;
BT          = Bnorm;%*BTref*S/35;
Tk          = T + 273.15;
Rsw         =  (d11Bsw/1000+1)*Rstd;
    
%% Kb calculate

% normal Dickson pKb calculation for standard SW chemistry
    tmp1	= -8966.9 - 2890.53*S.^0.5 - 77.942*S + 1.728*S.^(3/2) - 0.0996*S.^2;
    tmp2	= 148.0248 + 137.1942*S.^0.5 + 1.62142*S;
    tmp3	= -24.4344 - 25.085*S.^0.5 - 0.2474*S;
    lnKb    = tmp1./Tk + tmp2 + tmp3 .*log(Tk) + 0.053105.*S.^0.5 .*Tk;
    

%% P correction
a0	= -29.48;
a1	= 0.1622;
a2	= -0.002608;
b0	= -0.00284;
b1	= 0;
b2	= 0;

Pcor =-(a0+a1*T+a2*T.^2)/(R*Tk)*P+0.5*(b0+b1*T+b2*T.^2)/(R*Tk)*P.^2;

Kbval = exp(lnKb + Pcor);
pKb = -log10(Kbval);


%% boron calculations

%concentrations
cB3      = BT./(1+Kbval./(10.^-pH));
cB4      = BT./(1+(10.^-pH)./Kbval);

% isotopes
Hval = 10.^-pH;
RB4 = ((Hval.^2.*Rsw.^2 + 2*Hval.^2.*Rsw*alpha + Hval.^2*alpha^2 + 2*Hval.*Kbval.*Rsw.^2*alpha - 2*Hval.*Kbval.*Rsw*alpha^2 + 8*Hval.*Kbval.*Rsw*alpha - 2*Hval.*Kbval.*Rsw + 2*Hval.*Kbval*alpha + Kbval.^2.*Rsw.^2*alpha^2 + 2*Kbval.^2.*Rsw*alpha + Kbval.^2).^(1/2) - Hval.*alpha - Kbval + Hval.*Rsw + Kbval.*Rsw*alpha)./(2*alpha*(Hval + Kbval));
RB3 = RB4*alpha;



dB4 = (RB4./Rstd -1)*1000;
dB3 = (RB3./Rstd -1)*1000;

end